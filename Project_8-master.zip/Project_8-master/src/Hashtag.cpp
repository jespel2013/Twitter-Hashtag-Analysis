//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//


#include <string>
#include <iostream>
#include <algorithm>
#include <cctype>
#include "Hashtag.h"

using namespace std;

using namespace std;
Hashtag::Hashtag() {
	_content = "";
	_startCount = 0;
	_endCount = 0;
	_startRank = 0;
	_endRank = 0;
}

Hashtag::Hashtag(std::string content, unsigned int startCount, unsigned int endCount, unsigned int startRank, unsigned int endRank){
	_content = content;
	_startCount = startCount;
	_endCount = endCount;
	_startRank = startRank;
	_endRank = endRank;
}

// @requirement if there is no _endCount  (if it is equal to 0), the hashtag is invalid

bool Hashtag::IsValid() {

	if (_endCount == 0) {
		return false;
	}
	return true;
}

/**
* The lefthand side (lhs) Hashtag is less than the righthand (rhs) if (all string comparisons are case insensitive):


   If the rhs' end count is less than the lhs end count
   If the rhs' end count is equal to the lhs' end count, and both end counts are not 0, and the lhs' word is less than rhs' word alphabetically
   If both the rhs' and the lhs' end counts are 0, and the rhs' start count is less than the lhs' start count
   If both the rhs' and lhs' end counts are 0, and the rhs' start count is equal to the lhs' start count, and the lhs' word is less than the rhs' word alphabetically
*
*/

bool Hashtag::operator<(const Hashtag& rhs) const {

	if (_endCount > (unsigned)rhs.GetEndCount()) {
		return true;
	}
	if (_endCount == (unsigned)rhs.GetEndCount() && (_endCount != 0 && (unsigned)rhs.GetEndCount() != 0) && _content < rhs.GetContent()) {
		return true;
	}
	if ((_endCount == 0 && (unsigned)rhs.GetEndCount() == 0) && (_startCount >(unsigned)rhs.GetStartCount())) {
		return true;
	}
	if ((_endCount == 0 && (unsigned)rhs.GetEndCount() == 0) && (_startCount == (unsigned)rhs.GetStartCount()) && _content < rhs.GetContent()) {
		return true;
	}

	return false;
}