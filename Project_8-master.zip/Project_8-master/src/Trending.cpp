//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include <fstream>
#include <iostream>
#include <algorithm>
#include "Trending.h"
#include "Hashtag.h"

using namespace std;

Trending::Trending(std::string startHashtagFilePath, std::string endHashtagFilePath, std::string outputHashtagFilePath)
{
	_startHashtagFilePath = startHashtagFilePath;
	_endHashtagFilePath = endHashtagFilePath;
	_outputHashtagFilePath = outputHashtagFilePath;
}

void Trending::Run(){
	ReadStartHashtags();
	ReadEndHashtags();
	WriteHashtagFile();
	return;
}

/**
* Description: Read Start Hashtags from a File
*
*
* @requirement output error if _startHashtagFilePath cannot be opened
* @requirement populate the _hashtags vector with hashtags
* @requirement convert all words to lowercase
* @requirement Every string separated by whitespace characters (' ', '\t', '\n', '\r') is added to a vector
* @requirement A Card is added to the _hashtags list only if the Card is valid
* @requirement close the file stream when you are done.
*
*/
void Trending::ReadStartHashtags() {
	ifstream inFile;
	std::string word;
	unsigned int i;
	unsigned int wordFound = 0;

	inFile.open(_startHashtagFilePath);

	if (!inFile.is_open()) {
		cout << "_startHashtagFilePath unable to be opened" << endl;
		return;
	}
	
	while (inFile >> word) {
		for (i = 0; i < word.size(); i++) {
			word[i] = tolower(word[i]);
		}
		//search for word in _hashtags
		if (_hashtags.size() == 0) {
			Hashtag tempHashtag1 = Hashtag(word, 1, 0, 0, 0);
			_hashtags.push_back(tempHashtag1);
		}
		else {
			std::vector<Hashtag>::iterator currHashtag = _hashtags.begin();
			while (wordFound != 1 && currHashtag != _hashtags.end()) {
				if (currHashtag->GetContent().compare(word) == 0) {
					wordFound = 1;
					currHashtag->SetStartCount(currHashtag->GetStartCount() + 1);
					break;
				}
				else {
					currHashtag++;
				}
			}


			if (wordFound == 0) {
				Hashtag tempHashtag = Hashtag(word, 1, 0, 0, 0);
				_hashtags.push_back(tempHashtag);
			}
			wordFound = 0;
		}
	}

	inFile.close();
	sort(_hashtags.begin(), _hashtags.end()); 
	// assign start rank
	unsigned int rank = 1;
	for (std::vector<Hashtag>::iterator rankHashtags = _hashtags.begin(); rankHashtags != _hashtags.end(); rankHashtags++) {
		rankHashtags->SetStartRank(rank);
		if (rankHashtags != (_hashtags.end() - 1)) {
			if ((rankHashtags + 1)->GetStartCount() != rankHashtags->GetStartCount()) {
				rank++;
			}
		}
	}

	return;


}
void Trending::ReadEndHashtags() {
	ifstream inFile;
	std::string word;
	unsigned int i;
	unsigned int wordFound = 0;
	

	inFile.open(_endHashtagFilePath);

	if (!inFile.is_open()) {
		cout << "_endHashtagFilePath unable to be opened" << endl;
		return;
	}

	while (inFile >> word) {
		for (i = 0; i < word.size(); i++) {
			word[i] = tolower(word[i]);
		}
		//search for word in _hashtags
		std::vector<Hashtag>::iterator currHashtag = _hashtags.begin();
		while (wordFound != 1 && currHashtag != _hashtags.end()) {
			if (currHashtag->GetContent().compare(word) == 0) {
				wordFound = 1;
				currHashtag->SetEndCount(currHashtag->GetEndCount() + 1);
				break;
			}
			else {
				currHashtag++;
			}
		}

		if (wordFound == 0) {
			Hashtag tempHashtag = Hashtag(word, 0, 1, 0, 0);
			_hashtags.push_back(tempHashtag);
		}
		wordFound = 0;
	}

	inFile.close();
	sort(_hashtags.begin(), _hashtags.end()); 
	//assign end rank
	DeleteInvalidHashtags();
	unsigned int rank = 1;
	for (std::vector<Hashtag>::iterator rankHashtags = _hashtags.begin(); rankHashtags != _hashtags.end(); rankHashtags++) {
		rankHashtags->SetEndRank(rank);
		if (rankHashtags != (_hashtags.end() - 1)) {
			if ((rankHashtags + 1)->GetEndCount() != rankHashtags->GetEndCount()) {
				rank++;
			}
		}
	}
	return;
}



void Trending::DeleteInvalidHashtags() {
	for (std::vector<Hashtag>::iterator currHashtag = _hashtags.begin(); currHashtag != _hashtags.end(); currHashtag++) {
		if (!currHashtag->IsValid()) {
			currHashtag = _hashtags.erase(currHashtag);
			currHashtag--;
		}
	}
	return;
}

void Trending::WriteHashtagFile() {
	ofstream outFile;

	unsigned int difference;
	

	outFile.open(_outputHashtagFilePath);

	if (!outFile.is_open()) {
		cout << "Output file stream error" << endl;
		return;
	}

	for (std::vector<Hashtag>::iterator currHashtag = _hashtags.begin(); currHashtag != _hashtags.end(); currHashtag++) {
		if (currHashtag == _hashtags.begin()) { //first hashtag
			if (currHashtag->GetEndRank() == (currHashtag + 1)->GetEndRank()) {
				outFile << "T"; 
			}
			outFile << currHashtag->GetEndRank() << ": ";
		}
		else if (currHashtag == _hashtags.end()){ //last hashtag
			if (currHashtag->GetEndRank() == (currHashtag - 1)->GetEndRank()) {
				outFile << "T" << currHashtag->GetEndRank() << ": ";
			}
			outFile << currHashtag->GetEndRank() << ": ";
		}
		else { //all other hashtags
			if (currHashtag->GetEndRank() == (currHashtag + 1)->GetEndRank() || currHashtag->GetEndRank() == (currHashtag - 1)->GetEndRank()) {
				outFile << "T";
			}
			outFile << currHashtag->GetEndRank() << ": ";
		}

		// hashtag
		outFile << currHashtag->GetContent();


		//calculating difference

		difference = 0;
		if (currHashtag->GetStartRank() == 0) {
			outFile << " (new)" << endl;
		}
		else if (currHashtag->GetEndRank() == currHashtag->GetStartRank()) {
			difference = 0;
			outFile << " (+" << difference << ")" << endl;
		}
		else if(currHashtag->GetEndRank() < currHashtag->GetStartRank()) {
			difference = currHashtag->GetStartRank() - currHashtag->GetEndRank();
			outFile << " (+" << difference << ")" << endl;
		}
		else {
			difference = currHashtag->GetEndRank() - currHashtag->GetStartRank();
			outFile << " (-" << difference << ")" << endl;
		}
	}
	outFile.close();

	return;
}



