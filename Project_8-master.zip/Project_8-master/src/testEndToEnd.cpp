//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "testEndToEnd.h"
#include "Trending.h"
#include <algorithm>

using namespace std;

void EndToEndTester::RunTests(){
    for(int i = 0; i < 10; i++){
        cout << "Running file test " << i << endl;
        TestFile(i);
    }
}


/*
 * @requirement pass if all lines in files are the exact same (strcmp returns 0) AND output files can be opened properly
 * @return pass: 1, fail: 0
 */
int EndToEndTester::TestFile(int testNum){    
	ifstream outStream;
	ifstream myOutStream;

	std::string testOutput;
	std::string myOutput;

	stringstream testStartPath;
	stringstream testEndPath;
	stringstream myOutputFilePath;
	stringstream testOutputFilePath;


	testStartPath << TEST_FILE_RELATIVE_PATH << "/startHashtags" << testNum + 1 << ".txt";
	testEndPath << TEST_FILE_RELATIVE_PATH << "/endHashtags" << testNum + 1 << ".txt";
	testOutputFilePath << TEST_FILE_RELATIVE_PATH << "/output" << testNum + 1 << ".txt";
	myOutputFilePath << TEST_FILE_RELATIVE_PATH << "/myoutput" << testNum + 1 << ".txt";



	Trending Trending(testStartPath.str(), testEndPath.str(), myOutputFilePath.str());
	Trending.Run();
	//check to see if any line is different
	outStream.open(testOutputFilePath.str());
	myOutStream.open(myOutputFilePath.str());
	if (!outStream.is_open()) {
		cout << "Output stream failed to open\n";
		return false;
	}
	if (!myOutStream.is_open()) {
		cout << "My output stream failed to open\n";
		return false;
	}

	while (!myOutStream.eof()) {
		getline(myOutStream, myOutput);
		getline(outStream, testOutput);

		if (myOutput != testOutput) {
			cout << "test Failed\n";
			myOutStream.close();
			outStream.close();
			return false;

		}

	}
	cout << "test passed" << endl;
	myOutStream.close();
	outStream.close();
	return true;
}
