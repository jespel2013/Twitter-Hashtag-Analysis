//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//


#ifndef HASHTAG_H
#define HASHTAG_H

#include <string>

class Hashtag {
private:
    std::string _content;             // The hashtag itself
    unsigned int _startCount;         // Number of occurrences in start file
    unsigned int _endCount;           // Number of occurrences in end file
    unsigned int _startRank;          // Rank in start file
    unsigned int _endRank;            // Rank in end file
    
public:
	Hashtag();
	Hashtag(std::string content, unsigned int startCount, unsigned int endCount, unsigned int startRank, unsigned int endRank);
	//setters
	void SetContent(std::string content) { _content = content; };
	void SetStartCount(unsigned int startCount) { _startCount = startCount; };
	void SetEndCount(unsigned int endCount) { _endCount = endCount; };
	void SetStartRank(unsigned int startRank) { _startRank = startRank; };
	void SetEndRank(unsigned int endRank) { _endRank = endRank; };
	//getters
	std::string GetContent() const { return _content; };
	unsigned int GetStartCount() const { return _startCount; };
	unsigned int GetEndCount() const  {return _endCount; };
	unsigned int GetStartRank() const { return _startRank; };
	unsigned int GetEndRank() const { return _endRank; };
	//other functions
	bool IsValid();
	bool operator<(const Hashtag& rhs) const;  //not sure what do to with this
};

//--------------------------------------------------------------------------------------

#endif // HASHTAG_H
